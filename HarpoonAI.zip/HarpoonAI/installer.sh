#!/bin/bash
sudo hostnamectl set-hostname harpoonai
sudo yum install wget
sudo yum install git
mkdir -p "$HOME/offline_ai_chat"
chmod +x *.sh
cp start.sh ~/offline_ai_chat/ 2>/dev/null || true
cp stop.sh ~/offline_ai_chat/ 2>/dev/null || true
cp stopai.sh ~/offline_ai_chat/ 2>/dev/null || true
cp startai.sh ~/offline_ai_chat/ 2>/dev/null || true
cd "$HOME/offline_ai_chat"

# Run any existing setup scripts if they exist
if [ -f "startai.sh" ]; then
    echo "🔧 Running existing startai.sh..."
    ./startai.sh || true
fi
if [ -f "stopai.sh" ]; then
    echo "🔧 Running existing stopai.sh..."
    ./stopai.sh || true
fi
sudo yum install pip -y
pip install fastapi uvicorn
pip install --upgrade uvicorn
sudo yum update -y
sudo dnf install libcurl-devel -y
sudo dnf install file-devel -y
sudo dnf install libmagic-devel -y
sudo dnf install net-tools -y
set -e
sudo dnf install cmake gcc-c++ make openblas-devel

PROJECT_DIR="$HOME/offline_ai_chat"
MODEL_DIR="$PROJECT_DIR/models"
BACKEND_DIR="$PROJECT_DIR/backend"
FRONTEND_DIR="$PROJECT_DIR/frontend"
DATA_DIR="$PROJECT_DIR/data_ingest"
SELF_LEARN_DIR="$PROJECT_DIR/self_learn"
TRAINER_DIR="$PROJECT_DIR/trainer"
VENV_DIR="$PROJECT_DIR/venv"
DOCS_DIR="$PROJECT_DIR/documents"
UPLOAD_DIR="$PROJECT_DIR/uploads"

echo "🚀 Setting up Harpoon AI - Private GPT System..."
echo "Project directory: $PROJECT_DIR"

# Create all directories first
mkdir -p "$PROJECT_DIR" "$MODEL_DIR" "$BACKEND_DIR" "$FRONTEND_DIR" "$DATA_DIR" "$SELF_LEARN_DIR" "$TRAINER_DIR" "$DOCS_DIR" "$UPLOAD_DIR"

# Now change to project directory
cd "$PROJECT_DIR"

# Check for Python
PYTHON_BIN=$(which python3)
if [ -z "$PYTHON_BIN" ]; then
  echo "❌ Python3 not found. Please install Python 3.10+"
  exit 1
fi

echo "✅ Using Python: $PYTHON_BIN"

# Create virtual environment
echo "📦 Creating Python virtual environment..."
$PYTHON_BIN -m venv "$VENV_DIR"
source "$VENV_DIR/bin/activate"
pip install --upgrade pip
pip install fastapi uvicorn requests beautifulsoup4 readability-lxml tqdm numpy pandas
pip install python-multipart aiofiles docx2txt PyPDF2 pdfplumber openpyxl

# Try to install python-magic (works on most Linux systems)
pip install python-magic || echo "⚠️ python-magic not available, using fallback file detection"

# Clone llama.cpp
echo "📥 Cloning llama.cpp..."
if [ ! -d "llama.cpp" ]; then
  git clone https://github.com/ggerganov/llama.cpp.git
fi

cd llama.cpp

# Build llama.cpp with proper flags
echo "🔨 Building llama.cpp..."
mkdir -p build && cd build
cmake .. -DLLAMA_BLAS=ON -DLLAMA_BLAS_VENDOR=OpenBLAS -DLLAMA_NATIVE=ON -DLLAMA_SERVER=ON || {
  echo "❌ CMake failed. Try: sudo dnf install cmake gcc-c++ make openblas-devel"
  exit 1
}

make -j$(nproc) || { echo "❌ Build failed."; exit 1; }

echo "✅ Build completed. Contents:"
ls -la "$PROJECT_DIR/llama.cpp/build/"

# Look for the correct server binary
LLAMA_SERVER_BIN=""
for bin in \
  "$PROJECT_DIR/llama.cpp/build/bin/llama-server" \
  "$PROJECT_DIR/llama.cpp/build/llama-server" \
  "$PROJECT_DIR/llama.cpp/build/bin/server" \
  "$PROJECT_DIR/llama.cpp/build/server" \
  "$PROJECT_DIR/llama.cpp/build/bin/main" \
  "$PROJECT_DIR/llama.cpp/build/main"; do
  echo "Checking $bin"
  if [ -x "$bin" ]; then
    LLAMA_SERVER_BIN="$bin"
    echo "✅ Found LLaMA server binary: $LLAMA_SERVER_BIN"
    break
  fi
done

if [ -z "$LLAMA_SERVER_BIN" ]; then
  echo "❌ LLaMA server binary not found."
  echo "Available binaries in build directory:"
  find "$PROJECT_DIR/llama.cpp/build" -type f -executable | head -10
  exit 1
fi

cd "$PROJECT_DIR"

# Download Luna AI LLaMA model (correct filename)
echo "⬇️ Downloading Luna AI LLaMA model..."
LLAMA_MODEL_DIR="$MODEL_DIR/llama3"
mkdir -p "$LLAMA_MODEL_DIR"
LLAMA_MODEL_FILE="$LLAMA_MODEL_DIR/luna-ai-llama2-uncensored.Q4_K_M.gguf"

if [ ! -f "$LLAMA_MODEL_FILE" ]; then
  echo "📥 Downloading luna-ai-llama2-uncensored.Q4_K_M.gguf model..."
  wget -O "$LLAMA_MODEL_FILE" \
    "https://huggingface.co/TheBloke/Luna-AI-Llama2-Uncensored-GGUF/resolve/main/luna-ai-llama2-uncensored.Q4_K_M.gguf" || {
    echo "⚠️ Download failed, trying alternative source..."
    wget -O "$LLAMA_MODEL_FILE" \
      "https://huggingface.co/TheBloke/Luna-AI-Llama2-Uncensored-GGUF/resolve/main/luna-ai-llama2-uncensored.Q4_K_M.gguf"
  }
fi

# Download Falcon model
echo "⬇️ Downloading Falcon model..."
FALCON_MODEL_DIR="$MODEL_DIR/Falcon"
mkdir -p "$FALCON_MODEL_DIR"
FALCON_MODEL_FILE="$FALCON_MODEL_DIR/ehartford-WizardLM-Uncensored-Falcon-7b-Q2_K.gguf"

if [ ! -f "$FALCON_MODEL_FILE" ]; then
  echo "📥 Downloading Falcon model..."
  wget -O "$FALCON_MODEL_FILE" \
    "https://huggingface.co/maddes8cht/ehartford-WizardLM-Uncensored-Falcon-7b-gguf/resolve/main/ehartford-WizardLM-Uncensored-Falcon-7b-Q2_K.gguf" || {
    echo "⚠️ Download failed, trying alternative source..."
    wget -O "$FALCON_MODEL_FILE" \
      "https://huggingface.co/maddes8cht/ehartford-WizardLM-Uncensored-Falcon-7b-gguf/resolve/main/ehartford-WizardLM-Uncensored-Falcon-7b-Q2_K.gguf"
  }
fi

# Create Enhanced Backend FastAPI server with conversation memory and document processing
echo "🔧 Creating enhanced backend server with conversation memory..."
cat <<'EOF' > "$BACKEND_DIR/server.py"
import os
import json
import requests
import time
import uuid
import shutil
import re
from pathlib import Path
from typing import List, Optional, Dict, Any
from datetime import datetime
from fastapi import FastAPI, Request, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel

# Document processing imports
import PyPDF2
import pdfplumber
import docx2txt
import pandas as pd
from bs4 import BeautifulSoup

# Try to import python-magic, fall back to mimetypes if not available
try:
    import magic
    MAGIC_AVAILABLE = True
except ImportError:
    import mimetypes
    MAGIC_AVAILABLE = False
    print("⚠️ python-magic not available, using mimetypes for file detection")

# Get project directory from environment or use default
PROJECT_DIR = os.environ.get('PROJECT_DIR', os.path.expanduser("~/offline_ai_chat"))
SELF_LEARN_DIR = f"{PROJECT_DIR}/self_learn"
FRONTEND_DIR = f"{PROJECT_DIR}/frontend"
DOCS_DIR = f"{PROJECT_DIR}/documents"
UPLOAD_DIR = f"{PROJECT_DIR}/uploads"

LLAMA_API = "http://0.0.0.0:8080/completion"
FALCON_API = "http://0.0.0.0:8081/completion"
LOG_FILE = f"{SELF_LEARN_DIR}/conversations.jsonl"
DOCS_INDEX_FILE = f"{DOCS_DIR}/index.json"
CONVERSATIONS_FILE = f"{SELF_LEARN_DIR}/conversation_memory.json"

app = FastAPI(title="Harpoon AI - Private GPT", version="2.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class ConversationMemory:
    def __init__(self):
        self.conversations = {}
        self.load_conversations()

    def load_conversations(self):
        """Load conversation memory from file"""
        if os.path.exists(CONVERSATIONS_FILE):
            try:
                with open(CONVERSATIONS_FILE, 'r') as f:
                    self.conversations = json.load(f)
            except:
                self.conversations = {}

    def save_conversations(self):
        """Save conversation memory to file"""
        os.makedirs(os.path.dirname(CONVERSATIONS_FILE), exist_ok=True)
        with open(CONVERSATIONS_FILE, 'w') as f:
            json.dump(self.conversations, f, indent=2)

    def get_conversation(self, session_id: str) -> List[Dict]:
        """Get conversation history for a session"""
        return self.conversations.get(session_id, [])

    def add_message(self, session_id: str, role: str, content: str, metadata: Dict = None):
        """Add a message to conversation history"""
        if session_id not in self.conversations:
            self.conversations[session_id] = []

        message = {
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata or {}
        }

        self.conversations[session_id].append(message)

        # Keep only last 50 messages to prevent memory bloat
        if len(self.conversations[session_id]) > 50:
            self.conversations[session_id] = self.conversations[session_id][-50:]

        self.save_conversations()

    def get_conversation_context(self, session_id: str, max_exchanges: int = 5) -> str:
        """Get recent conversation context for the AI prompt"""
        history = self.get_conversation(session_id)
        if not history:
            return ""

        # Get the last max_exchanges*2 messages (user + assistant pairs)
        recent_messages = history[-(max_exchanges * 2):]
        context_parts = ["Previous conversation context:"]

        for msg in recent_messages:
            role = "Human" if msg["role"] == "user" else "Assistant"
            context_parts.append(f"{role}: {msg['content']}")

        context_parts.append("---")
        return "\n".join(context_parts)

    def clear_conversation(self, session_id: str):
        """Clear conversation history for a session"""
        if session_id in self.conversations:
            del self.conversations[session_id]
            self.save_conversations()

# Initialize conversation memory
conv_memory = ConversationMemory()

# Document processing utilities
class DocumentProcessor:
    def __init__(self):
        self.supported_formats = {
            'pdf': self.process_pdf,
            'docx': self.process_docx,
            'txt': self.process_txt,
            'csv': self.process_csv,
            'xlsx': self.process_excel,
            'html': self.process_html,
            'md': self.process_markdown
        }

    def get_file_type(self, file_path):
        """Detect file type using python-magic or mimetypes as fallback"""
        try:
            if MAGIC_AVAILABLE:
                # Try python-magic first
                file_type = magic.from_file(file_path, mime=True)
                if 'pdf' in file_type:
                    return 'pdf'
                elif 'word' in file_type or 'officedocument' in file_type:
                    return 'docx'
                elif 'text' in file_type:
                    return 'txt'
                elif 'csv' in file_type:
                    return 'csv'
                elif 'excel' in file_type or 'spreadsheet' in file_type:
                    return 'xlsx'
                elif 'html' in file_type:
                    return 'html'
            else:
                # Fallback to mimetypes
                mime_type, _ = mimetypes.guess_type(file_path)
                if mime_type:
                    if 'pdf' in mime_type:
                        return 'pdf'
                    elif 'word' in mime_type or 'officedocument' in mime_type:
                        return 'docx'
                    elif 'text' in mime_type:
                        return 'txt'
                    elif 'csv' in mime_type:
                        return 'csv'
                    elif 'excel' in mime_type or 'spreadsheet' in mime_type:
                        return 'xlsx'
                    elif 'html' in mime_type:
                        return 'html'
        except Exception as e:
            print(f"File type detection error: {e}")

        # Final fallback to extension-based detection
        ext = Path(file_path).suffix.lower().lstrip('.')
        if ext in self.supported_formats:
            return ext
        return None

    def process_pdf(self, file_path):
        """Extract text from PDF files"""
        text = ""
        try:
            # Try pdfplumber first (better for complex layouts)
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
        except Exception as e:
            print(f"pdfplumber failed: {e}")
            # Fallback to PyPDF2
            try:
                with open(file_path, 'rb') as file:
                    pdf_reader = PyPDF2.PdfReader(file)
                    for page in pdf_reader.pages:
                        page_text = page.extract_text()
                        if page_text:
                            text += page_text + "\n"
            except Exception as e2:
                raise Exception(f"Failed to extract text from PDF: {str(e2)}")

        if not text.strip():
            raise Exception("PDF appears to be empty or contains only images")
        return text.strip()

    def process_docx(self, file_path):
        """Extract text from DOCX files"""
        try:
            text = docx2txt.process(file_path)
            if not text.strip():
                raise Exception("DOCX file appears to be empty")
            return text.strip()
        except Exception as e:
            raise Exception(f"Failed to extract text from DOCX: {str(e)}")

    def process_txt(self, file_path):
        """Process plain text files"""
        try:
            # Try UTF-8 first
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read().strip()
                if content:
                    return content
        except UnicodeDecodeError:
            # Try different encodings
            for encoding in ['latin-1', 'cp1252', 'iso-8859-1', 'utf-16']:
                try:
                    with open(file_path, 'r', encoding=encoding) as file:
                        content = file.read().strip()
                        if content:
                            return content
                except:
                    continue
            raise Exception("Failed to decode text file with any supported encoding")

        if not content:
            raise Exception("Text file appears to be empty")
        return content

    def process_csv(self, file_path):
        """Process CSV files"""
        try:
            df = pd.read_csv(file_path)
            # Convert to readable format
            text = f"CSV Data Summary:\n"
            text += f"Columns: {', '.join(df.columns.tolist())}\n"
            text += f"Rows: {len(df)}\n\n"
            text += "Sample Data:\n"
            text += df.head(10).to_string(index=False)
            if len(df) > 10:
                text += f"\n... and {len(df) - 10} more rows"
            return text
        except Exception as e:
            raise Exception(f"Failed to process CSV: {str(e)}")

    def process_excel(self, file_path):
        """Process Excel files"""
        try:
            excel_file = pd.ExcelFile(file_path)
            text = f"Excel File: {Path(file_path).name}\n"
            text += f"Sheets: {', '.join(excel_file.sheet_names)}\n\n"

            for sheet_name in excel_file.sheet_names[:5]:  # Process first 5 sheets
                df = pd.read_excel(file_path, sheet_name=sheet_name)
                text += f"Sheet: {sheet_name}\n"
                text += f"Columns: {', '.join(df.columns.tolist())}\n"
                text += f"Rows: {len(df)}\n"
                text += df.head(5).to_string(index=False)
                text += "\n\n"

            return text.strip()
        except Exception as e:
            raise Exception(f"Failed to process Excel: {str(e)}")

    def process_html(self, file_path):
        """Process HTML files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                html_content = file.read()

            soup = BeautifulSoup(html_content, 'html.parser')
            # Remove script and style elements
            for script in soup(["script", "style"]):
                script.decompose()

            text = soup.get_text()
            # Clean up whitespace
            lines = (line.strip() for line in text.splitlines())
            chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
            text = ' '.join(chunk for chunk in chunks if chunk)

            return text
        except Exception as e:
            raise Exception(f"Failed to process HTML: {str(e)}")

    def process_markdown(self, file_path):
        """Process Markdown files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()

            # Basic markdown processing - remove markdown syntax
            text = re.sub(r'#+\s*', '', content)  # Remove headers
            text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)  # Remove bold
            text = re.sub(r'\*(.*?)\*', r'\1', text)  # Remove italic
            text = re.sub(r'`(.*?)`', r'\1', text)  # Remove inline code
            text = re.sub(r'```.*?```', '', text, flags=re.DOTALL)  # Remove code blocks
            text = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', text)  # Remove links

            return text.strip()
        except Exception as e:
            raise Exception(f"Failed to process Markdown: {str(e)}")

    def process_document(self, file_path):
        """Process a document and extract text"""
        file_type = self.get_file_type(file_path)
        if not file_type or file_type not in self.supported_formats:
            raise Exception(f"Unsupported file type: {file_type}")

        processor = self.supported_formats[file_type]
        return processor(file_path)

# Initialize document processor
doc_processor = DocumentProcessor()

# Document index management
def load_document_index():
    """Load document index from file"""
    if os.path.exists(DOCS_INDEX_FILE):
        try:
            with open(DOCS_INDEX_FILE, 'r') as f:
                return json.load(f)
        except:
            pass
    return {"documents": []}

def save_document_index(index):
    """Save document index to file"""
    os.makedirs(os.path.dirname(DOCS_INDEX_FILE), exist_ok=True)
    with open(DOCS_INDEX_FILE, 'w') as f:
        json.dump(index, f, indent=2)

def add_document_to_index(doc_info):
    """Add document to index"""
    index = load_document_index()
    index["documents"].append(doc_info)
    save_document_index(index)

def search_documents(query, limit=5):
    """Simple keyword search in documents"""
    index = load_document_index()
    results = []

    query_lower = query.lower()
    for doc in index["documents"]:
        # Simple keyword matching
        content_lower = doc.get("content", "").lower()
        title_lower = doc.get("title", "").lower()

        if query_lower in content_lower or query_lower in title_lower:
            # Calculate relevance score
            score = content_lower.count(query_lower) + title_lower.count(query_lower) * 2
            results.append({**doc, "relevance_score": score})

    # Sort by relevance and return top results
    results.sort(key=lambda x: x["relevance_score"], reverse=True)
    return results[:limit]

def get_document_context(query, max_context_length=2000):
    """Get relevant document context for a query"""
    relevant_docs = search_documents(query, limit=3)

    context = ""
    if relevant_docs:
        context = "\n--- RELEVANT DOCUMENTS ---\n"
        for doc in relevant_docs:
            context += f"\nDocument: {doc['title']}\n"
            content = doc['content'][:800]  # Limit content length per document
            if len(doc['content']) > 800:
                content += "..."
            context += content + "\n"
        context += "--- END DOCUMENTS ---\n"

    return context[:max_context_length]

def check_model_server(api_url, model_name):
    """Check if model server is responding"""
    try:
        # Try health check first
        health_url = api_url.replace('/completion', '/health')
        response = requests.get(health_url, timeout=5)
        if response.status_code == 200:
            return True
    except:
        pass

    # Try simple completion as fallback
    try:
        payload = {"prompt": "test", "n_predict": 1}
        response = requests.post(api_url, json=payload, timeout=10)
        return response.status_code == 200
    except Exception as e:
        print(f"Model server {model_name} not responding: {e}")
        return False

@app.get("/health")
async def health_check():
    llama_ok = check_model_server(LLAMA_API, "LLaMA")
    falcon_ok = check_model_server(FALCON_API, "Falcon")

    doc_index = load_document_index()
    doc_count = len(doc_index["documents"])

    return {
        "status": "ok",
        "models": {
            "llama": "online" if llama_ok else "offline",
            "falcon": "online" if falcon_ok else "offline"
        },
        "documents": {
            "count": doc_count,
            "indexed": doc_count > 0
        }
    }

@app.get("/conversation/{session_id}")
async def get_conversation(session_id: str):
    """Get conversation history for a session"""
    history = conv_memory.get_conversation(session_id)
    return {"conversation": history}

@app.delete("/conversation/{session_id}")
async def clear_conversation(session_id: str):
    """Clear conversation history for a session"""
    conv_memory.clear_conversation(session_id)
    return {"message": "Conversation cleared"}

@app.post("/upload-document")
async def upload_document(
    file: UploadFile = File(...),
    title: Optional[str] = Form(None)
):
    """Upload and process a document"""
    try:
        # Generate unique filename
        file_id = str(uuid.uuid4())
        file_extension = Path(file.filename).suffix
        saved_filename = f"{file_id}{file_extension}"
        file_path = os.path.join(UPLOAD_DIR, saved_filename)

        # Save uploaded file
        os.makedirs(UPLOAD_DIR, exist_ok=True)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # Process document
        try:
            content = doc_processor.process_document(file_path)
        except Exception as e:
            os.remove(file_path)  # Clean up failed upload
            raise HTTPException(status_code=400, detail=f"Failed to process document: {str(e)}")

        # Create document info
        doc_info = {
            "id": file_id,
            "title": title or file.filename,
            "filename": file.filename,
            "saved_filename": saved_filename,
            "file_type": doc_processor.get_file_type(file_path),
            "content": content,
            "upload_date": datetime.now().isoformat(),
            "size": len(content)
        }

        # Add to index
        add_document_to_index(doc_info)

        return {
            "message": "Document uploaded and processed successfully",
            "document_id": file_id,
            "title": doc_info["title"],
            "file_type": doc_info["file_type"],
            "content_length": len(content)
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Upload failed: {str(e)}")

@app.get("/documents")
async def list_documents():
    """List all uploaded documents"""
    index = load_document_index()
    documents = []

    for doc in index["documents"]:
        documents.append({
            "id": doc["id"],
            "title": doc["title"],
            "filename": doc["filename"],
            "file_type": doc["file_type"],
            "upload_date": doc["upload_date"],
            "size": doc["size"]
        })

    return {"documents": documents}

@app.delete("/documents/{document_id}")
async def delete_document(document_id: str):
    """Delete a document"""
    index = load_document_index()

    # Find and remove document
    doc_to_remove = None
    for i, doc in enumerate(index["documents"]):
        if doc["id"] == document_id:
            doc_to_remove = index["documents"].pop(i)
            break

    if not doc_to_remove:
        raise HTTPException(status_code=404, detail="Document not found")

    # Remove file
    file_path = os.path.join(UPLOAD_DIR, doc_to_remove["saved_filename"])
    if os.path.exists(file_path):
        os.remove(file_path)

    # Save updated index
    save_document_index(index)

    return {"message": "Document deleted successfully"}

@app.post("/chat")
async def chat_endpoint(request: Request):
    try:
        data = await request.json()
        prompt = data.get("message", "")
        model = data.get("model", "llama")
        response_length = data.get("response_length", "unlimited")
        use_documents = data.get("use_documents", True)
        session_id = data.get("session_id", "default")

        if not prompt.strip():
            return {"reply": "Please enter a message"}

        api = LLAMA_API if model == "llama" else FALCON_API
        model_name = "LLaMA" if model == "llama" else "Falcon"

        # Check if model server is running
        if not check_model_server(api, model_name):
            return {"reply": f"❌ {model_name} model server is not responding. Please check if the model servers are running."}

        # Build the enhanced prompt with conversation context and documents
        enhanced_prompt = ""
        context_used = False

        # Add conversation context
        conversation_context = conv_memory.get_conversation_context(session_id, max_exchanges=4)
        if conversation_context:
            enhanced_prompt += conversation_context + "\n\n"
            context_used = True

        # Get document context if enabled
        if use_documents:
            doc_context = get_document_context(prompt)
            if doc_context:
                enhanced_prompt += doc_context + "\n\n"
                context_used = True

        # Add current user message
        enhanced_prompt += f"Human: {prompt}\nAssistant: "

        # Set response length based on user preference
        if response_length == "unlimited":
            n_predict = -1
        elif response_length == "long":
            n_predict = 1000
        elif response_length == "medium":
            n_predict = 500
        elif response_length == "short":
            n_predict = 200
        else:
            try:
                n_predict = int(response_length)
            except:
                n_predict = -1

        payload = {
            "prompt": enhanced_prompt,
            "n_predict": n_predict,
            "temperature": 0.7,
            "stop": ["Human:", "Assistant:", "</s>"],
            "stream": False,
            "repeat_penalty": 1.1,
            "top_k": 40,
            "top_p": 0.9,
            "min_p": 0.1,
            "typical_p": 1.0,
            "tfs_z": 1.0,
            "mirostat": 0,
            "mirostat_tau": 5.0,
            "mirostat_eta": 0.1
        }

        print(f"Sending request to {api} with session: {session_id}")
        print(f"Using conversation context: {bool(conversation_context)}")
        print(f"Using document context: {use_documents and bool(get_document_context(prompt))}")

        timeout = 300 if n_predict == -1 else 120
        res = requests.post(api, json=payload, timeout=timeout)

        print(f"Response status: {res.status_code}")

        if res.status_code != 200:
            return {"reply": f"❌ Model server error: HTTP {res.status_code} - {res.text}"}

        response_data = res.json()
        reply = response_data.get("content", "").strip()

        # Clean up the reply (remove any repeated prompts)
        if "Human:" in reply:
            reply = reply.split("Human:")[0].strip()
        if "Assistant:" in reply:
            reply = reply.replace("Assistant:", "").strip()

        # Store the conversation in memory
        conv_memory.add_message(session_id, "user", prompt, {"model": model, "use_documents": use_documents})
        conv_memory.add_message(session_id, "assistant", reply, {"model": model, "context_used": context_used})

        # Log conversation to file for backwards compatibility
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        with open(LOG_FILE, "a") as log:
            log.write(json.dumps({
                "user": prompt,
                "bot": reply,
                "model": model,
                "session_id": session_id,
                "response_length": response_length,
                "context_used": context_used,
                "timestamp": time.time()
            }) + "\n")

        return {
            "reply": reply or "No response generated",
            "context_used": context_used,
            "session_id": session_id
        }

    except requests.exceptions.Timeout:
        return {"reply": "❌ Request timed out. The model might be generating a very long response or is overloaded."}
    except requests.exceptions.ConnectionError as e:
        return {"reply": f"❌ Cannot connect to {model_name} model server. Please check if it's running."}
    except Exception as e:
        print(f"Error in chat endpoint: {e}")
        return {"reply": f"❌ ERROR: {str(e)}"}

@app.get("/search-documents")
async def search_documents_endpoint(query: str, limit: int = 5):
    """Search documents for a query"""
    results = search_documents(query, limit)
    return {"results": results}

@app.get("/ingest")
def ingest_url(url: str):
    try:
        res = requests.get(url, timeout=10)
        from readability import Document
        from bs4 import BeautifulSoup

        doc = Document(res.text)
        soup = BeautifulSoup(doc.summary(), "html.parser")
        text = soup.get_text()

        # Add to documents instead of just self_learn
        doc_info = {
            "id": str(uuid.uuid4()),
            "title": f"Web Content: {url}",
            "filename": f"web_{int(time.time())}.txt",
            "saved_filename": f"web_{int(time.time())}.txt",
            "file_type": "web",
            "content": text.strip()[:10000],
            "upload_date": datetime.now().isoformat(),
            "size": len(text.strip()[:10000]),
            "source_url": url
        }

        add_document_to_index(doc_info)

        # Also keep the old behavior for backwards compatibility
        os.makedirs(SELF_LEARN_DIR, exist_ok=True)
        with open(f"{SELF_LEARN_DIR}/web_ingest.txt", "a") as f:
            f.write(f"\n\n--- SOURCE: {url} ---\n{text.strip()[:10000]}\n")

        return "✅ Ingested and indexed: " + url
    except Exception as e:
        return "❌ Error: " + str(e)

# Serve the HTML interface
@app.get("/")
async def serve_index():
    return FileResponse(f"{FRONTEND_DIR}/index.html")

# Mount static files
if os.path.exists(FRONTEND_DIR):
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")
EOF