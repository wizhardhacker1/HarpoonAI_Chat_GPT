cd ~/offline_ai_chat
source venv/bin/activate
./start.sh